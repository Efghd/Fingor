function setup() {
  createCanvas(200, 100);
}

function draw() {
  background('rgb(120,255,00)');
  quad(120, 20, 180, 20, 180, 80, 120, 80);
  circle(60,50,60)
}